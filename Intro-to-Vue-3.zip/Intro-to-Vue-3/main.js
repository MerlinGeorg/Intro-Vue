const app=Vue.createApp({
    data(){
        return {
         
            isDisabled:true,
            isButtonDisabled: true,
            isActive:true,
            hasError:true,
            fontSize: 30,
           /*  classObject:{
                active:true,
                hasError:true,

            } */
           /*  styleObject:{
                fontSize:'30px'
            } */
            awesome:true,
            type:'B',
            ok:false,
           
            newItemPriority:'low',
            // newItemHighPriority:'low priority'
            newItemHighPriority:false,
            iceCreamFlavours:[],

            
        }
    }
})



