app.component('product-display',{
template:
/*html*/`
<review-list v-if="reviews.length" :reviews="reviews">
<review-form @review-submitted="addReview"></review-form>

`,
data(){
  return{
    reviews:[]
  }
},
methods:{
  addReview(review){
    this.reviews.push(review)
  }
}
})